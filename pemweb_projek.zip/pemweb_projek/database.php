<?php
$hoshame = "localhost";
$dbname = "darurraahmah";
$username = "root";
$password = "";

$conn = new mysqli($hoshame, $dbname, $password, $dbname);

?>