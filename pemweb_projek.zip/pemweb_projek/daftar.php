<?php

echo date("l", mktime(0,0,0,2,18,1974));

?>